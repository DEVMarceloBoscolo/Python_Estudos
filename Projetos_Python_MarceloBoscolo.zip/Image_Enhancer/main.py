# Image Enhancer - Otimizador de Imagens
# Desenvolvido por marceloboscolo

from PIL import Image, ImageEnhance

def melhorar_imagem(caminho):
    try:
        img = Image.open(caminho)
        enhancer = ImageEnhance.Contrast(img)
        img = enhancer.enhance(1.5)
        img.show()
    except FileNotFoundError:
        print("Arquivo de imagem não encontrado.")

if __name__ == "__main__":
    melhorar_imagem('imagem.jpg')
