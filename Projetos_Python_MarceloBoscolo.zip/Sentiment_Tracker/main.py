# Sentiment Tracker - Analisador de Sentimentos
# Desenvolvido por marceloboscolo

from textblob import TextBlob

posts = [
    "Adorei o novo curso de Python!",
    "Hoje o dia foi cansativo...",
    "O produto não funciona como esperado."
]

def analisar_sentimentos(textos):
    for texto in textos:
        analise = TextBlob(texto)
        sentimento = "Positivo" if analise.sentiment.polarity > 0 else "Negativo" if analise.sentiment.polarity < 0 else "Neutro"
        print(f"'{texto}' -> {sentimento}")

if __name__ == "__main__":
    analisar_sentimentos(posts)
