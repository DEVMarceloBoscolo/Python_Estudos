# Sentiment Tracker
Analisa sentimentos de textos usando Python.
Desenvolvido por marceloboscolo.