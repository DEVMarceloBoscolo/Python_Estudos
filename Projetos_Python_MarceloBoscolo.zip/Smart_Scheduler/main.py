# Smart Scheduler - Organizador de Tarefas Inteligente
# Desenvolvido por marceloboscolo

import datetime

tarefas = []

def adicionar_tarefa(nome, duracao):
    tarefas.append({"nome": nome, "duracao": duracao})

def mostrar_agenda():
    agora = datetime.datetime.now()
    print("Agenda para hoje:")
    for t in tarefas:
        print(f"- {t['nome']} ({t['duracao']} min)")

if __name__ == "__main__":
    adicionar_tarefa("Estudar Python", 90)
    adicionar_tarefa("Projeto Data Science", 120)
    mostrar_agenda()
