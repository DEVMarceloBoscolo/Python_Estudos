# Smart Scheduler
Aplicativo que organiza tarefas baseado em prioridades.
Desenvolvido por marceloboscolo.