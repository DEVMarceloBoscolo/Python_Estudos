# Data Cleaner Pro - Limpeza Automática de Dados
# Desenvolvido por marceloboscolo

import pandas as pd

def limpar_dados(df):
    print("Valores ausentes antes da limpeza:\n", df.isnull().sum())
    df = df.fillna(df.mean(numeric_only=True))
    df = df.drop_duplicates()
    print("Dados limpos com sucesso!")
    return df

if __name__ == "__main__":
    try:
        df = pd.read_csv('dataset.csv')
        df_limpo = limpar_dados(df)
        df_limpo.to_csv('dataset_limpo.csv', index=False)
    except FileNotFoundError:
        print("Arquivo 'dataset.csv' não encontrado. Crie um CSV para testar.")
