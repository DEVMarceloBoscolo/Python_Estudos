# Analytica Finance - Analisador de Gastos Pessoais
# Desenvolvido por marceloboscolo

import pandas as pd
import matplotlib.pyplot as plt

def carregar_dados(caminho):
    return pd.read_csv(caminho)

def analisar_gastos(df):
    resumo = df.groupby('Categoria')['Valor'].sum()
    print("Resumo de Gastos:\n", resumo)
    resumo.plot(kind='bar', title='Gastos por Categoria')
    plt.show()

if __name__ == "__main__":
    try:
        df = carregar_dados('extrato.csv')
        analisar_gastos(df)
    except FileNotFoundError:
        print("Arquivo 'extrato.csv' não encontrado. Crie um CSV com colunas: Data, Descrição, Categoria, Valor")
