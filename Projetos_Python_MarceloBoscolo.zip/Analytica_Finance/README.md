# Analytica Finance
Ferramenta para análise de gastos pessoais em CSV.
Desenvolvido por marceloboscolo.